// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCu-oEjeP9aQOhyo73wcz_R4eHNJWQPi1Y",
  authDomain: "thrivepulse-88544.firebaseapp.com",
  projectId: "thrivepulse-88544",
  storageBucket: "thrivepulse-88544.firebasestorage.app",
  messagingSenderId: "57238518422",
  appId: "1:57238518422:web:ad4608801b5effd26a20b7",
  measurementId: "G-4R8F8FHZWD"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const analytics = getAnalytics(app);

// API URL for backend
export const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

export default app; 