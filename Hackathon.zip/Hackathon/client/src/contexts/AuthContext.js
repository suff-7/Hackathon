import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  getIdToken
} from 'firebase/auth';
import { auth } from '../firebase';

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Demo mode bypass
  const [demoMode, setDemoMode] = useState(false);

  function signup(email, password, name) {
    return createUserWithEmailAndPassword(auth, email, password);
  }

  function login(email, password) {
    // Demo mode bypass for demo credentials
    if (email.includes('@thrivepulse.com') && password === 'password123') {
      setDemoMode(true);
      setCurrentUser({
        uid: 'demo-user',
        email: email,
        displayName: email.split('@')[0],
        getIdToken: () => Promise.resolve('demo-token')
      });
      return Promise.resolve();
    }
    return signInWithEmailAndPassword(auth, email, password);
  }

  function logout() {
    setDemoMode(false);
    return signOut(auth);
  }

  async function getToken() {
    if (demoMode) {
      return 'demo-token';
    }
    if (currentUser) {
      return await currentUser.getIdToken();
    }
    return null;
  }

  useEffect(() => {
    if (!demoMode) {
      const unsubscribe = onAuthStateChanged(auth, (user) => {
        setCurrentUser(user);
        setLoading(false);
      });

      return unsubscribe;
    } else {
      setLoading(false);
    }
  }, [demoMode]);

  const value = {
    currentUser,
    login,
    signup,
    logout,
    getToken,
    error,
    setError,
    demoMode
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
} 