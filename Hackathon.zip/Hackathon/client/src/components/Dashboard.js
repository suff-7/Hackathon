import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import Sidebar from './layout/Sidebar';
import Header from './layout/Header';
import DashboardHome from './dashboard/DashboardHome';
import MoodTracker from './dashboard/MoodTracker';
import TaskManager from './dashboard/TaskManager';
import TeamMetrics from './dashboard/TeamMetrics';
import TherapistBot from './dashboard/TherapistBot';
import AnonymousMessages from './dashboard/AnonymousMessages';
import NotificationSystem from './common/NotificationSystem';

function Dashboard() {
  const [activeTab, setActiveTab] = useState('home');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const { currentUser, getToken } = useAuth();

  const addNotification = (message, type = 'info') => {
    const id = Date.now();
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 5000);
  };

  useEffect(() => {
    // Welcome notification
    if (currentUser) {
      addNotification(`Welcome back, ${currentUser.email?.split('@')[0]}!`, 'success');
    }
  }, [currentUser]);

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <DashboardHome addNotification={addNotification} />;
      case 'mood':
        return <MoodTracker addNotification={addNotification} />;
      case 'tasks':
        return <TaskManager addNotification={addNotification} />;
      case 'metrics':
        return <TeamMetrics addNotification={addNotification} />;
      case 'therapist':
        return <TherapistBot addNotification={addNotification} />;
      case 'messages':
        return <AnonymousMessages addNotification={addNotification} />;
      default:
        return <DashboardHome addNotification={addNotification} />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-900">
      {/* Sidebar */}
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab}
        sidebarOpen={sidebarOpen}
        setSidebarOpen={setSidebarOpen}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <Header 
          setSidebarOpen={setSidebarOpen}
          addNotification={addNotification}
        />

        {/* Content */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-900">
          <div className="max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </main>
      </div>

      {/* Notification System */}
      <NotificationSystem notifications={notifications} />
      
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 z-40 bg-black bg-opacity-75 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}

export default Dashboard; 