import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageCircle, 
  Send, 
  Calendar, 
  Clock, 
  User, 
  Bot,
  Heart,
  Smile,
  Coffee,
  Moon
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

function TherapistBot({ addNotification }) {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [sessions, setSessions] = useState([]);
  const [showScheduler, setShowScheduler] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const messagesEndRef = useRef(null);
  const { getToken } = useAuth();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Initialize with welcome message
    setMessages([
      {
        id: 1,
        text: "Hello! I'm ThrivePulse AI Therapist 🤖 I'm here to support your mental health and well-being. How are you feeling today?",
        sender: 'bot',
        timestamp: new Date()
      }
    ]);
    fetchSessions();
  }, []);

  const fetchSessions = async () => {
    try {
      const token = await getToken();
      const response = await fetch(`${process.env.REACT_APP_API_URL || 'http://localhost:3001'}/api/therapist/sessions`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setSessions(data);
      }
    } catch (error) {
      console.error('Failed to fetch sessions:', error);
    }
  };

  const scheduleSession = async () => {
    if (!selectedDate || !selectedTime) {
      addNotification('Please select both date and time', 'error');
      return;
    }

    try {
      const token = await getToken();
      const scheduledTime = new Date(`${selectedDate}T${selectedTime}`);
      
      const response = await fetch(`${process.env.REACT_APP_API_URL || 'http://localhost:3001'}/api/therapist/session`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          scheduledTime: scheduledTime.toISOString(),
          sessionType: 'wellness-consultation',
          notes: 'Scheduled via ThrivePulse'
        })
      });

      if (response.ok) {
        addNotification('Therapist session scheduled successfully! 📅', 'success');
        setShowScheduler(false);
        setSelectedDate('');
        setSelectedTime('');
        fetchSessions();
      } else {
        addNotification('Failed to schedule session', 'error');
      }
    } catch (error) {
      console.error('Failed to schedule session:', error);
      addNotification('Failed to schedule session', 'error');
    }
  };

  const getBotResponse = (userMessage) => {
    const message = userMessage.toLowerCase();
    
    // Simple pattern matching for responses
    if (message.includes('stress') || message.includes('anxiety') || message.includes('worried')) {
      return {
        text: "I understand you're feeling stressed. Here are some techniques that might help: 🧘‍♀️ Try deep breathing exercises, 🚶‍♀️ take a short walk, or 🎵 listen to calming music. Would you like me to guide you through a breathing exercise?",
        suggestions: ['Yes, guide me through breathing', 'Tell me about stress management', 'I need professional help']
      };
    }
    
    if (message.includes('sad') || message.includes('down') || message.includes('depressed')) {
      return {
        text: "I'm sorry you're feeling down. Remember that it's okay to have difficult days. 💙 Some things that might help: ☀️ getting some sunlight, 📞 talking to a friend, or 📝 journaling your thoughts. Your feelings are valid, and I'm here to support you.",
        suggestions: ['Tell me about mood improvement', 'Schedule a real session', 'Share coping strategies']
      };
    }
    
    if (message.includes('tired') || message.includes('exhausted') || message.includes('burnout')) {
      return {
        text: "Feeling tired or burnt out is a sign your body and mind need rest. 😴 Consider: getting better sleep, 🛑 taking regular breaks, 🏃‍♀️ gentle exercise, or 🍃 practicing mindfulness. Work-life balance is crucial for well-being.",
        suggestions: ['Sleep tips', 'Burnout prevention', 'Schedule time off']
      };
    }
    
    if (message.includes('angry') || message.includes('frustrated') || message.includes('mad')) {
      return {
        text: "Anger is a normal emotion, but it's important to manage it healthily. 🌬️ Try: counting to 10, 🏃‍♀️ physical exercise, 🎨 creative outlets, or 🗣️ expressing your feelings calmly. What's causing your frustration?",
        suggestions: ['Anger management tips', 'Talk about the issue', 'Relaxation techniques']
      };
    }
    
    if (message.includes('happy') || message.includes('good') || message.includes('great') || message.includes('excellent')) {
      return {
        text: "That's wonderful to hear! 🌟 I'm so glad you're feeling positive. Keep nurturing that good energy with activities you enjoy, 🤝 connecting with loved ones, and 🎯 setting meaningful goals. What's contributing to your happiness today?",
        suggestions: ['Share your success', 'Gratitude practice', 'Maintain positive habits']
      };
    }
    
    if (message.includes('sleep') || message.includes('insomnia')) {
      return {
        text: "Sleep is crucial for mental health. 🌙 For better sleep: 📱 avoid screens before bed, 🛏️ create a relaxing bedtime routine, 🍵 try herbal tea, and 🌡️ keep your room cool and dark. Consistent sleep schedule helps too!",
        suggestions: ['Sleep hygiene tips', 'Relaxation techniques', 'Schedule check-up']
      };
    }

    if (message.includes('help') || message.includes('support')) {
      return {
        text: "I'm here to help! 💙 I can provide emotional support, coping strategies, wellness tips, and help you schedule sessions with real therapists. What specific support do you need today?",
        suggestions: ['Coping strategies', 'Schedule real session', 'Emergency resources']
      };
    }

    // Default responses
    const defaultResponses = [
      {
        text: "Thank you for sharing that with me. 💙 Everyone's mental health journey is unique. Can you tell me more about how you're feeling right now?",
        suggestions: ['I feel stressed', 'I feel sad', 'I feel anxious', 'I feel good']
      },
      {
        text: "I appreciate you opening up. 🤗 Mental wellness is important, and small steps can make a big difference. What would be most helpful for you today?",
        suggestions: ['Breathing exercises', 'Mood tracking', 'Talk to someone', 'Self-care tips']
      },
      {
        text: "Your well-being matters to me. 🌱 Sometimes just talking about our feelings can be therapeutic. Would you like some personalized wellness suggestions?",
        suggestions: ['Yes, give me tips', 'Schedule a session', 'Learn about mindfulness']
      }
    ];

    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
  };

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const userMessage = {
      id: Date.now(),
      text: newMessage,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setNewMessage('');

    // Simulate typing delay
    setTimeout(() => {
      const botResponse = getBotResponse(newMessage);
      const botMessage = {
        id: Date.now() + 1,
        text: botResponse.text,
        sender: 'bot',
        timestamp: new Date(),
        suggestions: botResponse.suggestions
      };
      setMessages(prev => [...prev, botMessage]);
    }, 1000);
  };

  const handleSuggestionClick = (suggestion) => {
    setNewMessage(suggestion);
    setTimeout(() => {
      handleSendMessage();
    }, 100);
  };

  const formatTime = (date) => {
    return new Date(date).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Therapist Bot & Sessions</h2>
          <p className="text-gray-600">Get immediate support or schedule professional help</p>
        </div>
        <button
          onClick={() => setShowScheduler(!showScheduler)}
          className="bg-gradient-to-r from-purple-500 to-pink-600 text-white px-4 py-2 rounded-lg hover:from-purple-600 hover:to-pink-700 transition-all duration-200 flex items-center"
        >
          <Calendar className="w-4 h-4 mr-2" />
          Schedule Session
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chat Interface */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-lg">
          {/* Chat Header */}
          <div className="border-b border-gray-200 p-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div className="ml-3">
                <h3 className="font-semibold">ThrivePulse AI Therapist</h3>
                <p className="text-sm text-green-600 flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                  Online & ready to help
                </p>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="h-96 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                  message.sender === 'user' 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-gray-100 text-gray-900'
                }`}>
                  <p className="text-sm">{message.text}</p>
                  <p className={`text-xs mt-1 ${message.sender === 'user' ? 'text-blue-100' : 'text-gray-500'}`}>
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                  
                  {/* Suggestion buttons */}
                  {message.suggestions && (
                    <div className="mt-3 space-y-1">
                      {message.suggestions.map((suggestion, index) => (
                        <button
                          key={index}
                          onClick={() => handleSuggestionClick(suggestion)}
                          className="block w-full text-left px-3 py-1 bg-white text-gray-700 rounded border hover:bg-gray-50 text-sm"
                        >
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Message Input */}
          <div className="border-t border-gray-200 p-4">
            <div className="flex space-x-2">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Type your message..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <button
                onClick={handleSendMessage}
                className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors duration-200"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Sidebar - Sessions & Quick Actions */}
        <div className="space-y-6">
          {/* Session Scheduler */}
          {showScheduler && (
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold mb-4">Schedule Therapist Session</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Time</label>
                  <select
                    value={selectedTime}
                    onChange={(e) => setSelectedTime(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    <option value="">Select time</option>
                    <option value="09:00">9:00 AM</option>
                    <option value="10:00">10:00 AM</option>
                    <option value="11:00">11:00 AM</option>
                    <option value="14:00">2:00 PM</option>
                    <option value="15:00">3:00 PM</option>
                    <option value="16:00">4:00 PM</option>
                  </select>
                </div>
                <button
                  onClick={scheduleSession}
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-600 text-white py-2 px-4 rounded-lg hover:from-purple-600 hover:to-pink-700 transition-all duration-200"
                >
                  Schedule Session
                </button>
              </div>
            </div>
          )}

          {/* Upcoming Sessions */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <Calendar className="w-5 h-5 mr-2 text-purple-500" />
              Upcoming Sessions
            </h3>
            {sessions.length > 0 ? (
              <div className="space-y-3">
                {sessions.slice(0, 3).map((session, index) => (
                  <div key={index} className="p-3 bg-purple-50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-purple-900">Therapy Session</p>
                        <p className="text-sm text-purple-600 flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {formatTime(session.scheduledTime)}
                        </p>
                      </div>
                      <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center text-gray-500 py-4">
                <Calendar className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                <p>No upcoming sessions</p>
                <p className="text-sm">Schedule one when you need support</p>
              </div>
            )}
          </div>

          {/* Quick Wellness Tips */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <Heart className="w-5 h-5 mr-2 text-red-500" />
              Quick Wellness Tips
            </h3>
            <div className="space-y-3">
              <div className="p-3 bg-green-50 rounded-lg flex items-center">
                <Coffee className="w-5 h-5 text-green-600 mr-3" />
                <div>
                  <p className="text-sm font-medium">Take regular breaks</p>
                  <p className="text-xs text-gray-600">Every 60 minutes</p>
                </div>
              </div>
              <div className="p-3 bg-blue-50 rounded-lg flex items-center">
                <Smile className="w-5 h-5 text-blue-600 mr-3" />
                <div>
                  <p className="text-sm font-medium">Practice gratitude</p>
                  <p className="text-xs text-gray-600">3 things daily</p>
                </div>
              </div>
              <div className="p-3 bg-purple-50 rounded-lg flex items-center">
                <Moon className="w-5 h-5 text-purple-600 mr-3" />
                <div>
                  <p className="text-sm font-medium">Get enough sleep</p>
                  <p className="text-xs text-gray-600">7-9 hours nightly</p>
                </div>
              </div>
            </div>
          </div>

          {/* Emergency Resources */}
          <div className="bg-red-50 border border-red-200 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-red-800 mb-2">Need Immediate Help?</h3>
            <p className="text-sm text-red-700 mb-4">
              If you're in crisis, please contact emergency services or a crisis hotline immediately.
            </p>
            <div className="space-y-2 text-sm">
              <p className="text-red-800 font-medium">Emergency: 911</p>
              <p className="text-red-800 font-medium">Crisis Text Line: Text HOME to 741741</p>
              <p className="text-red-800 font-medium">National Suicide Prevention Lifeline: 988</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TherapistBot; 