import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Users, 
  TrendingUp, 
  Target, 
  Clock, 
  Heart,
  CheckCircle,
  AlertTriangle,
  Calendar,
  MessageSquare,
  Shield,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Line, Doughnut, Bar, Radar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  RadialLinearScale,
  BarElement,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  RadialLinearScale,
  BarElement
);

function DashboardHome({ addNotification }) {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const { getToken, currentUser } = useAuth();

  useEffect(() => {
    fetchMetrics();
    // Show daily wellness reminder
    const welcomeTimer = setTimeout(() => {
      addNotification("Welcome to ThrivePulse! Don't forget to check in with your mood today! 😊", 'info');
    }, 3000);

    return () => clearTimeout(welcomeTimer);
  }, []);

  const fetchMetrics = async () => {
    try {
      const token = await getToken();
      const response = await fetch(`${process.env.REACT_APP_API_URL || 'http://localhost:3001'}/api/metrics/team`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setMetrics(data);
      }
    } catch (error) {
      console.error('Failed to fetch metrics:', error);
    } finally {
      setLoading(false);
    }
  };

  const teamPulseData = {
    labels: ['Communication', 'Collaboration', 'Motivation', 'Stress Level', 'Work-Life Balance', 'Job Satisfaction'],
    datasets: [
      {
        label: 'Team Member A',
        data: [7, 8, 6, 8, 7, 9],
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        borderColor: 'rgb(59, 130, 246)',
        borderWidth: 2,
        pointBackgroundColor: 'rgb(59, 130, 246)',
      },
      {
        label: 'Team Member B',
        data: [8, 7, 9, 6, 8, 7],
        backgroundColor: 'rgba(34, 197, 94, 0.1)',
        borderColor: 'rgb(34, 197, 94)',
        borderWidth: 2,
        pointBackgroundColor: 'rgb(34, 197, 94)',
      },
    ],
  };

  const CircularProgress = ({ value, label }) => (
    <div className="relative w-40 h-40 mx-auto">
      <svg className="w-40 h-40 transform -rotate-90" viewBox="0 0 144 144">
        {/* Background circle */}
        <circle
          cx="72"
          cy="72"
          r="60"
          stroke="rgba(75, 85, 99, 0.3)"
          strokeWidth="8"
          fill="none"
        />
        {/* Progress circle */}
        <circle
          cx="72"
          cy="72"
          r="60"
          stroke="url(#gradient)"
          strokeWidth="8"
          fill="none"
          strokeLinecap="round"
          strokeDasharray={`${(value / 100) * 377} 377`}
          className="transition-all duration-1000 ease-out"
        />
        {/* Gradient definition */}
        <defs>
          <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#3b82f6" />
            <stop offset="50%" stopColor="#8b5cf6" />
            <stop offset="100%" stopColor="#06b6d4" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-4xl font-bold text-white">{value}</span>
        <span className="text-sm text-gray-400 mt-1">{label}</span>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="loading-spinner border-blue-500"></div>
        <span className="ml-3 text-gray-300">Loading dashboard...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6 bg-gray-900 min-h-screen">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">ThrivePulse Dashboard</h1>
        <p className="text-gray-400">Your team's wellness and productivity insights with empathy at the core</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column */}
        <div className="space-y-6">
          {/* Team Pulse Circle */}
          <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-2xl p-6">
            <CircularProgress value={78} label="Team Pulse" />
            <div className="text-center mt-4">
              <p className="text-green-400 text-sm font-medium">Positive momentum building</p>
              <div className="flex items-center justify-center mt-2 text-gray-400 text-sm">
                <div className="flex items-center mr-4">
                  <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                  +2 more
                </div>
                <span>team members</span>
              </div>
            </div>
          </div>

          {/* Professional Therapist */}
          <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-2xl p-6">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-lg mr-4">
                DSC
              </div>
              <div>
                <h3 className="text-white font-semibold">Dr. Sarah Chen</h3>
                <p className="text-gray-400 text-sm">Licensed Clinical Therapist</p>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="bg-green-500 text-white text-xs px-3 py-1 rounded-full">Available now</span>
            </div>
            <div className="mt-4 p-3 bg-purple-500/10 border border-purple-500/20 rounded-lg">
              <div className="flex items-start">
                <Heart className="w-5 h-5 text-purple-400 mt-0.5 mr-3 flex-shrink-0" />
                <div>
                  <p className="text-white font-medium text-sm">Professional support when you need it</p>
                  <p className="text-gray-400 text-xs mt-1">Your wellbeing is our priority. I'm here to help.</p>
                </div>
              </div>
            </div>
            
            {/* Issue Banner */}
            <div className="mt-4 bg-red-500/10 border border-red-500/20 rounded-lg p-3 flex items-center">
              <AlertTriangle className="w-4 h-4 text-red-400 mr-2" />
              <span className="text-red-400 text-sm">1 issue</span>
            </div>
          </div>
        </div>

        {/* Center Column */}
        <div className="space-y-6">
          {/* Your Voice Matters */}
          <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-2xl p-6 text-center">
            <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-6 h-6 text-green-400" />
            </div>
            <h3 className="text-xl font-semibold text-blue-400 mb-3">Your Voice Matters</h3>
            <p className="text-gray-400 text-sm mb-6">
              This is a safe space to share your thoughts, concerns, or feedback with leadership.
            </p>
            <input
              type="text"
              placeholder="Share what's on your mind... completely anonymous"
              className="w-full bg-gray-700/50 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-500 mb-4 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <button 
              onClick={() => addNotification("Message sent anonymously! 📤", 'success')}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-6 py-2 rounded-lg font-medium transition-all duration-200 flex items-center mx-auto"
            >
              <Shield className="w-4 h-4 mr-2" />
              Send to Leadership
            </button>
          </div>

          {/* Success Banner */}
          <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4">
            <div className="flex items-center">
              <Sparkles className="w-5 h-5 text-green-400 mr-3" />
              <div>
                <p className="text-green-400 font-medium">Orchids is done!</p>
                <p className="text-gray-400 text-sm">1 with care, is create a better workplace for everyone.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Team Care Radar */}
        <div className="space-y-6">
          <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-2xl p-6">
            <div className="flex items-center mb-4">
              <Heart className="w-5 h-5 text-pink-400 mr-2" />
              <h3 className="text-white font-semibold">Team Care Radar</h3>
            </div>
            <p className="text-gray-400 text-sm mb-6">Supporting each other's wellbeing</p>
            
            {/* Team Member Cards */}
            <div className="space-y-4">
              <div className="border border-yellow-500/30 rounded-lg p-4 bg-yellow-500/5">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-white font-medium">Team Member A</h4>
                  <span className="text-yellow-400 text-sm">Needs Support</span>
                </div>
                <div className="text-gray-400 text-sm">
                  <p>Wellbeing: 28/100</p>
                  <p>Score: 6</p>
                </div>
                <p className="text-gray-400 text-xs mt-2">Could use some extra support right now</p>
              </div>

              <div className="border border-orange-500/30 rounded-lg p-4 bg-orange-500/5">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-white font-medium">Team Member B</h4>
                  <span className="text-orange-400 text-sm">Needs Attention</span>
                </div>
                <div className="text-gray-400 text-sm">
                  <p>Wellbeing: 52/100</p>
                  <p>Score: 7</p>
                </div>
                <p className="text-gray-400 text-xs mt-2">Might benefit from a check-in or support conversation</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-6 space-y-3">
              <button 
                onClick={() => addNotification("Anonymous care message sent! 💝", 'success')}
                className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white py-2 px-4 rounded-lg font-medium transition-all duration-200 text-sm"
              >
                Send Anonymous Care Message
              </button>
              <button 
                onClick={() => addNotification("Care message sent! 💝", 'success')}
                className="w-full bg-gray-700/50 hover:bg-gray-700 text-white py-2 px-4 rounded-lg font-medium transition-all duration-200 text-sm border border-gray-600"
              >
                Send Anonymous Care Message
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section - Team Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        {/* Team Radar Chart */}
        <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-2xl p-6">
          <h3 className="text-white font-semibold mb-4">Team Assessment Radar</h3>
          <div className="chart-container">
            <Radar 
              data={teamPulseData} 
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    labels: {
                      color: 'white'
                    }
                  }
                },
                scales: {
                  r: {
                    beginAtZero: true,
                    max: 10,
                    ticks: {
                      color: 'rgba(156, 163, 175, 0.7)',
                      stepSize: 2,
                    },
                    grid: {
                      color: 'rgba(156, 163, 175, 0.2)',
                    },
                    angleLines: {
                      color: 'rgba(156, 163, 175, 0.2)',
                    }
                  }
                }
              }} 
            />
          </div>
        </div>

        {/* Quick Stats */}
        <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-2xl p-6">
          <h3 className="text-white font-semibold mb-4">Today's Insights</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-green-500/10 rounded-lg border border-green-500/20">
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                <span className="text-white">Tasks Completed</span>
              </div>
              <span className="text-green-400 font-semibold">87%</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
              <div className="flex items-center">
                <Heart className="w-5 h-5 text-blue-400 mr-3" />
                <span className="text-white">Average Mood</span>
              </div>
              <span className="text-blue-400 font-semibold">8.2/10</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-purple-500/10 rounded-lg border border-purple-500/20">
              <div className="flex items-center">
                <Users className="w-5 h-5 text-purple-400 mr-3" />
                <span className="text-white">Team Engagement</span>
              </div>
              <span className="text-purple-400 font-semibold">94%</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-yellow-500/10 rounded-lg border border-yellow-500/20">
              <div className="flex items-center">
                <Target className="w-5 h-5 text-yellow-400 mr-3" />
                <span className="text-white">Wellness Score</span>
              </div>
              <span className="text-yellow-400 font-semibold">78/100</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DashboardHome; 