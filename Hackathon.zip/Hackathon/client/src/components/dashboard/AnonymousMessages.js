import React, { useState } from 'react';
import { Mail, Send, MessageSquare, Shield, AlertCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

function AnonymousMessages({ addNotification }) {
  const [message, setMessage] = useState('');
  const [department, setDepartment] = useState('general');
  const [priority, setPriority] = useState('medium');
  const [loading, setLoading] = useState(false);
  const { getToken } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!message.trim()) {
      addNotification('Please enter a message', 'error');
      return;
    }

    setLoading(true);

    try {
      const token = await getToken();
      const response = await fetch(`${process.env.REACT_APP_API_URL || 'http://localhost:3001'}/api/messages/anonymous`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          message,
          department,
          priority
        })
      });

      if (response.ok) {
        addNotification('Anonymous message sent successfully! 📤', 'success');
        setMessage('');
        setDepartment('general');
        setPriority('medium');
      } else {
        addNotification('Failed to send message', 'error');
      }
    } catch (error) {
      console.error('Failed to send message:', error);
      addNotification('Failed to send message', 'error');
    } finally {
      setLoading(false);
    }
  };

  const departments = [
    { value: 'general', label: 'General' },
    { value: 'hr', label: 'Human Resources' },
    { value: 'management', label: 'Management' },
    { value: 'it', label: 'IT Support' },
    { value: 'wellness', label: 'Wellness Team' }
  ];

  const priorities = [
    { value: 'low', label: 'Low', color: 'text-green-600' },
    { value: 'medium', label: 'Medium', color: 'text-yellow-600' },
    { value: 'high', label: 'High', color: 'text-red-600' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Anonymous Messages</h2>
          <p className="text-gray-600">Share feedback or concerns safely and anonymously</p>
        </div>
        <div className="flex items-center space-x-2 text-green-600">
          <Shield className="w-5 h-5" />
          <span className="text-sm font-medium">100% Anonymous</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Message Form */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center mb-6">
            <Mail className="w-6 h-6 text-blue-500 mr-3" />
            <h3 className="text-lg font-semibold">Send Anonymous Message</h3>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Message */}
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                Your Message *
              </label>
              <textarea
                id="message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows="6"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Share your thoughts, concerns, feedback, or suggestions. Your identity will remain completely anonymous."
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                {message.length}/1000 characters
              </p>
            </div>

            {/* Department and Priority */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="department" className="block text-sm font-medium text-gray-700 mb-2">
                  Department
                </label>
                <select
                  id="department"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {departments.map((dept) => (
                    <option key={dept.value} value={dept.value}>
                      {dept.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="priority" className="block text-sm font-medium text-gray-700 mb-2">
                  Priority Level
                </label>
                <select
                  id="priority"
                  value={priority}
                  onChange={(e) => setPriority(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {priorities.map((p) => (
                    <option key={p.value} value={p.value}>
                      {p.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Privacy Notice */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-start">
                <Shield className="w-5 h-5 text-blue-600 mt-0.5 mr-3 flex-shrink-0" />
                <div>
                  <h4 className="text-sm font-medium text-blue-900 mb-1">Privacy Guarantee</h4>
                  <p className="text-sm text-blue-700">
                    Your message is completely anonymous. No identifying information is stored or tracked. 
                    Leadership will receive your feedback without knowing who sent it.
                  </p>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading || !message.trim()}
              className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-4 rounded-lg hover:from-blue-600 hover:to-purple-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center"
            >
              {loading ? (
                'Sending...'
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Send Anonymous Message
                </>
              )}
            </button>
          </form>
        </div>

        {/* Information Sidebar */}
        <div className="space-y-6">
          {/* Why Anonymous Messages */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <MessageSquare className="w-5 h-5 mr-2 text-green-500" />
              Why Anonymous Feedback?
            </h3>
            <div className="space-y-3 text-sm text-gray-600">
              <div className="flex items-start">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <p>Encourages honest communication without fear of retaliation</p>
              </div>
              <div className="flex items-start">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <p>Helps identify workplace issues that might otherwise go unreported</p>
              </div>
              <div className="flex items-start">
                <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <p>Creates a safe space for constructive feedback and suggestions</p>
              </div>
              <div className="flex items-start">
                <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <p>Promotes a culture of continuous improvement and transparency</p>
              </div>
            </div>
          </div>

          {/* Message Guidelines */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <AlertCircle className="w-5 h-5 mr-2 text-yellow-500" />
              Message Guidelines
            </h3>
            <div className="space-y-3 text-sm">
              <div className="p-3 bg-green-50 rounded-lg">
                <p className="font-medium text-green-800 mb-1">✅ Encouraged:</p>
                <ul className="text-green-700 space-y-1">
                  <li>• Constructive feedback</li>
                  <li>• Workplace concerns</li>
                  <li>• Improvement suggestions</li>
                  <li>• Process issues</li>
                </ul>
              </div>
              <div className="p-3 bg-red-50 rounded-lg">
                <p className="font-medium text-red-800 mb-1">❌ Not Appropriate:</p>
                <ul className="text-red-700 space-y-1">
                  <li>• Personal attacks</li>
                  <li>• Discriminatory language</li>
                  <li>• False accusations</li>
                  <li>• Confidential information</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Response Information */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Response Process</h3>
            <div className="space-y-3 text-sm text-gray-600">
              <div className="flex items-center">
                <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                  <span className="text-blue-600 font-bold text-xs">1</span>
                </div>
                <p>Message reviewed by leadership team</p>
              </div>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-yellow-100 rounded-full flex items-center justify-center mr-3">
                  <span className="text-yellow-600 font-bold text-xs">2</span>
                </div>
                <p>Issues addressed or investigated</p>
              </div>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mr-3">
                  <span className="text-green-600 font-bold text-xs">3</span>
                </div>
                <p>Follow-up actions communicated to team</p>
              </div>
            </div>
          </div>

          {/* Contact for Urgent Issues */}
          <div className="bg-orange-50 border border-orange-200 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-orange-800 mb-2">Urgent Issues?</h3>
            <p className="text-sm text-orange-700 mb-4">
              For immediate concerns requiring urgent attention, please contact:
            </p>
            <div className="space-y-2 text-sm">
              <p className="text-orange-800 font-medium">HR Director: ext. 2001</p>
              <p className="text-orange-800 font-medium">Employee Assistance: 1-800-HELP</p>
              <p className="text-orange-800 font-medium">Ethics Hotline: ethics@company.com</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AnonymousMessages; 