import React, { useState, useEffect } from 'react';
import { Calendar, TrendingUp, Heart, Smile, Frown, Meh } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

function MoodTracker({ addNotification }) {
  const [mood, setMood] = useState(5);
  const [notes, setNotes] = useState('');
  const [anonymous, setAnonymous] = useState(false);
  const [loading, setLoading] = useState(false);
  const [moodHistory, setMoodHistory] = useState([]);
  const { getToken } = useAuth();

  const moodEmojis = {
    1: '😢', 2: '😔', 3: '😐', 4: '🙂', 5: '😊',
    6: '😄', 7: '😆', 8: '🤗', 9: '😍', 10: '🤩'
  };

  const moodLabels = {
    1: 'Very Sad', 2: 'Sad', 3: 'Neutral', 4: 'Good', 5: 'Happy',
    6: 'Very Happy', 7: 'Excited', 8: 'Joyful', 9: 'Amazing', 10: 'Ecstatic'
  };

  const getMoodColor = (moodValue) => {
    if (moodValue <= 3) return 'text-red-500';
    if (moodValue <= 6) return 'text-yellow-500';
    return 'text-green-500';
  };

  const getMoodBgColor = (moodValue) => {
    if (moodValue <= 3) return 'bg-red-50 border-red-200';
    if (moodValue <= 6) return 'bg-yellow-50 border-yellow-200';
    return 'bg-green-50 border-green-200';
  };

  useEffect(() => {
    fetchMoodHistory();
  }, []);

  const fetchMoodHistory = async () => {
    try {
      const token = await getToken();
      const response = await fetch(`${process.env.REACT_APP_API_URL || 'http://localhost:3001'}/api/mood/history`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setMoodHistory(data);
      }
    } catch (error) {
      console.error('Failed to fetch mood history:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const token = await getToken();
      const response = await fetch(`${process.env.REACT_APP_API_URL || 'http://localhost:3001'}/api/mood/checkin`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          mood,
          notes,
          anonymous
        })
      });

      if (response.ok) {
        addNotification(`Mood check-in recorded! Feeling ${moodLabels[mood].toLowerCase()} today 🎉`, 'success');
        setNotes('');
        fetchMoodHistory(); // Refresh the history
      } else {
        addNotification('Failed to record mood check-in', 'error');
      }
    } catch (error) {
      console.error('Failed to submit mood:', error);
      addNotification('Failed to record mood check-in', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Prepare chart data
  const chartData = {
    labels: moodHistory.slice(-7).map(entry => 
      new Date(entry.timestamp || entry.date).toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric' 
      })
    ),
    datasets: [
      {
        label: 'Mood Level',
        data: moodHistory.slice(-7).map(entry => entry.mood),
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        borderWidth: 3,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: 'rgb(59, 130, 246)',
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 6,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: 'Your Mood Trend (Last 7 Days)',
        font: {
          size: 16,
          weight: 'bold',
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 10,
        ticks: {
          stepSize: 1,
        },
      },
    },
  };

  const averageMood = moodHistory.length > 0 
    ? moodHistory.reduce((sum, entry) => sum + entry.mood, 0) / moodHistory.length 
    : 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Mood Tracker</h2>
          <p className="text-gray-600">How are you feeling today?</p>
        </div>
        <div className="flex items-center space-x-2">
          <TrendingUp className="w-6 h-6 text-blue-500" />
          <span className="text-sm text-gray-600">
            Avg Mood: {averageMood.toFixed(1)}/10
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Mood Check-in Form */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <Heart className="w-5 h-5 mr-2 text-red-500" />
            Daily Check-in
          </h3>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Current Mood Display */}
            <div className={`p-6 rounded-lg border-2 text-center ${getMoodBgColor(mood)}`}>
              <div className="text-6xl mb-2">{moodEmojis[mood]}</div>
              <div className={`text-2xl font-bold ${getMoodColor(mood)}`}>
                {moodLabels[mood]}
              </div>
              <div className="text-gray-600 mt-1">{mood}/10</div>
            </div>

            {/* Mood Slider */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mood Level (1-10)
              </label>
              <input
                type="range"
                min="1"
                max="10"
                value={mood}
                onChange={(e) => setMood(parseInt(e.target.value))}
                className="w-full mood-slider"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>😢 Very Sad</span>
                <span>😊 Happy</span>
                <span>🤩 Ecstatic</span>
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Notes (Optional)
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows="3"
                placeholder="How are you feeling? What's on your mind?"
              />
            </div>

            {/* Anonymous Toggle */}
            <div className="flex items-center">
              <input
                type="checkbox"
                id="anonymous"
                checked={anonymous}
                onChange={(e) => setAnonymous(e.target.checked)}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              />
              <label htmlFor="anonymous" className="ml-2 text-sm text-gray-700">
                Submit anonymously
              </label>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-4 rounded-lg hover:from-blue-600 hover:to-purple-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
            >
              {loading ? 'Submitting...' : 'Record Mood Check-in'}
            </button>
          </form>
        </div>

        {/* Mood History Chart */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-blue-500" />
            Mood History
          </h3>

          {moodHistory.length > 0 ? (
            <div className="chart-container">
              <Line data={chartData} options={chartOptions} />
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-64 text-gray-500">
              <Smile className="w-12 h-12 mb-4" />
              <p>No mood data yet</p>
              <p className="text-sm">Start tracking your mood to see trends!</p>
            </div>
          )}

          {/* Recent Check-ins */}
          {moodHistory.length > 0 && (
            <div className="mt-6">
              <h4 className="font-medium text-gray-900 mb-3">Recent Check-ins</h4>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {moodHistory.slice(0, 5).map((entry, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <div className="flex items-center">
                      <span className="text-lg mr-2">{moodEmojis[entry.mood]}</span>
                      <span className="text-sm text-gray-600">
                        {new Date(entry.timestamp || entry.date).toLocaleDateString()}
                      </span>
                    </div>
                    <span className={`text-sm font-medium ${getMoodColor(entry.mood)}`}>
                      {entry.mood}/10
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default MoodTracker; 