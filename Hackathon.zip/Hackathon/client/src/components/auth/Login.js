import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { Heart, Activity, Users, Shield, Eye, EyeOff } from 'lucide-react';

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { login, error, setError } = useAuth();
  const navigate = useNavigate();

  const demoCredentials = [
    { email: 'shancy.coordinator@thrivepulse.com', password: 'password123', role: 'Team Coordinator' },
    { email: 'zuhair.member@thrivepulse.com', password: 'password123', role: 'Team Member' },
    { email: 'shrikhar.member@thrivepulse.com', password: 'password123', role: 'Team Member' },
    { email: 'yashaswi.member@thrivepulse.com', password: 'password123', role: 'Team Member' },
    { email: 'sufyaan.member@thrivepulse.com', password: 'password123', role: 'Team Member' }
  ];

  async function handleSubmit(e) {
    e.preventDefault();
    
    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }

    try {
      setLoading(true);
      await login(email, password);
      navigate('/dashboard');
    } catch (error) {
      console.error('Login failed:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleDemoLogin = (demoEmail, demoPassword) => {
    setEmail(demoEmail);
    setPassword(demoPassword);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Left Side - Branding */}
        <div className="flex flex-col justify-center space-y-8 text-white">
          {/* Logo and Header */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mb-6">
              <Heart className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              ThrivePulse Dashboard
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Your team's wellness and productivity insights with empathy at the core
            </p>
          </div>

          {/* Features Preview */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-xl p-6 text-center">
              <Activity className="w-8 h-8 text-blue-400 mx-auto mb-3" />
              <h3 className="font-semibold text-white mb-2">Health Tracking</h3>
              <p className="text-sm text-gray-400">Monitor team wellness in real-time</p>
            </div>
            <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-xl p-6 text-center">
              <Users className="w-8 h-8 text-green-400 mx-auto mb-3" />
              <h3 className="font-semibold text-white mb-2">Team Analytics</h3>
              <p className="text-sm text-gray-400">Data-driven insights for better teams</p>
            </div>
            <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-xl p-6 text-center">
              <Shield className="w-8 h-8 text-purple-400 mx-auto mb-3" />
              <p className="text-sm text-gray-400">Anonymous support and feedback</p>
            </div>
            <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-xl p-6 text-center">
              <Heart className="w-8 h-8 text-pink-400 mx-auto mb-3" />
              <p className="text-sm text-gray-400">AI-powered wellness support</p>
            </div>
          </div>
        </div>

        {/* Right Side - Login Form */}
        <div className="flex items-center justify-center">
          <div className="w-full max-w-md">
            <div className="bg-gray-800/80 backdrop-blur border border-gray-700 rounded-2xl shadow-2xl p-8">
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold text-white mb-2">Welcome Back</h2>
                <p className="text-gray-400">Sign in to access your dashboard</p>
              </div>

              {/* Login Form */}
              <form onSubmit={handleSubmit} className="space-y-6">
                {error && (
                  <div className="bg-red-500/10 border border-red-500/20 text-red-400 px-4 py-3 rounded-lg text-sm">
                    {error}
                  </div>
                )}
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400"
                    placeholder="your@email.com"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-300 mb-2">
                    Password
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      id="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400 pr-12"
                      placeholder="••••••••"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-300"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white py-3 px-4 rounded-lg font-medium transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? 'Signing In...' : 'Sign In'}
                </button>
              </form>

              {/* Demo Credentials */}
              <div className="mt-8">
                <div className="flex items-center mb-4">
                  <div className="flex-1 h-px bg-gray-600"></div>
                  <span className="px-3 text-sm text-gray-400">Demo Credentials</span>
                  <div className="flex-1 h-px bg-gray-600"></div>
                </div>
                
                <div className="space-y-3 max-h-48 overflow-y-auto">
                  {demoCredentials.map((demo, index) => (
                    <button
                      key={index}
                      onClick={() => handleDemoLogin(demo.email, demo.password)}
                      className="w-full text-left p-3 bg-gray-700/30 hover:bg-gray-700/50 border border-gray-600/50 rounded-lg transition-all duration-200 group"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-white group-hover:text-blue-400">
                            {demo.email}
                          </p>
                          <p className="text-xs text-gray-400">{demo.role}</p>
                        </div>
                        <div className="text-xs text-gray-500">
                          Click to use
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Footer */}
              <div className="mt-6 text-center">
                <p className="text-sm text-gray-400">
                  Don't have an account?{' '}
                  <Link to="/register" className="text-blue-400 hover:text-blue-300 font-medium">
                    Sign up here
                  </Link>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login; 