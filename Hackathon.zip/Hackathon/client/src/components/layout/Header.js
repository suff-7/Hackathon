import React, { useState, useEffect } from 'react';
import { Menu, Bell, User, Settings, Sun, Moon } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

function Header({ setSidebarOpen, addNotification }) {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [darkMode, setDarkMode] = useState(true); // Default to dark mode
  const { currentUser } = useAuth();

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const motivationalMessages = [
    "You're doing great! Keep up the excellent work! 🌟",
    "Remember to take a short break and stretch! 🧘‍♀️",
    "Stay hydrated! Drink some water 💧",
    "Take a deep breath and smile! 😊",
    "You've got this! Every step counts! 💪",
    "Remember to check in with your team! 👥",
    "Your well-being matters! Take care of yourself! ❤️"
  ];

  const showMotivationalMessage = () => {
    const randomMessage = motivationalMessages[Math.floor(Math.random() * motivationalMessages.length)];
    addNotification(randomMessage, 'success');
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <header className="bg-gray-800/80 backdrop-blur border-b border-gray-700 px-6 py-4">
      <div className="flex items-center justify-between">
        {/* Left side - Mobile menu button */}
        <div className="flex items-center">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500 transition-colors duration-200"
          >
            <Menu className="w-6 h-6" />
          </button>
          
          {/* Date and Time */}
          <div className="ml-4 lg:ml-0">
            <h1 className="text-xl font-semibold text-white">
              Good {new Date().getHours() < 12 ? 'Morning' : new Date().getHours() < 18 ? 'Afternoon' : 'Evening'}!
            </h1>
            <p className="text-sm text-gray-400">
              {formatDate(currentTime)} • {formatTime(currentTime)}
            </p>
          </div>
        </div>

        {/* Right side - User controls */}
        <div className="flex items-center space-x-4">
          {/* Motivational Button */}
          <button
            onClick={showMotivationalMessage}
            className="hidden md:flex items-center px-4 py-2 bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 text-white rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            ✨ Get Motivated
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-700 transition-colors duration-200"
            title="Toggle dark mode"
          >
            {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>

          {/* Notifications */}
          <button
            className="relative p-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-700 transition-colors duration-200"
            title="Notifications"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>

          {/* Settings */}
          <button
            className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-700 transition-colors duration-200"
            title="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>

          {/* User Profile */}
          <div className="flex items-center space-x-3">
            <div className="hidden md:block text-right">
              <p className="text-sm font-medium text-white">
                {currentUser?.email?.split('@')[0] || 'User'}
              </p>
              <p className="text-xs text-green-400 flex items-center justify-end">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
                Online
              </p>
            </div>
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center ring-2 ring-gray-600">
              <User className="w-4 h-4 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats Bar */}
      <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-blue-500/10 backdrop-blur border border-blue-500/20 p-3 rounded-lg">
          <p className="text-xs text-blue-400 font-medium">Today's Mood</p>
          <p className="text-lg font-bold text-blue-300">😊 Good</p>
        </div>
        <div className="bg-green-500/10 backdrop-blur border border-green-500/20 p-3 rounded-lg">
          <p className="text-xs text-green-400 font-medium">Tasks Completed</p>
          <p className="text-lg font-bold text-green-300">3/5</p>
        </div>
        <div className="bg-purple-500/10 backdrop-blur border border-purple-500/20 p-3 rounded-lg">
          <p className="text-xs text-purple-400 font-medium">Team Health</p>
          <p className="text-lg font-bold text-purple-300">85%</p>
        </div>
        <div className="bg-orange-500/10 backdrop-blur border border-orange-500/20 p-3 rounded-lg">
          <p className="text-xs text-orange-400 font-medium">Streak</p>
          <p className="text-lg font-bold text-orange-300">7 days</p>
        </div>
      </div>
    </header>
  );
}

export default Header; 