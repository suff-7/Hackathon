import React from 'react';
import { 
  Heart, 
  Home, 
  Activity, 
  CheckSquare, 
  BarChart3, 
  MessageCircle, 
  Mail, 
  LogOut 
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

function Sidebar({ activeTab, setActiveTab, sidebarOpen, setSidebarOpen }) {
  const { logout } = useAuth();

  const menuItems = [
    { id: 'home', name: 'Dashboard', icon: Home },
    { id: 'mood', name: 'Mood Tracker', icon: Activity },
    { id: 'tasks', name: 'Tasks', icon: CheckSquare },
    { id: 'metrics', name: 'Team Metrics', icon: BarChart3 },
    { id: 'therapist', name: 'Therapist Bot', icon: MessageCircle },
    { id: 'messages', name: 'Anonymous Messages', icon: Mail },
  ];

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return (
    <>
      {/* Sidebar */}
      <div className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-gray-900/95 backdrop-blur border-r border-gray-800 shadow-2xl transform transition-transform duration-300 ease-in-out
        lg:translate-x-0 lg:static lg:inset-0
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        {/* Logo */}
        <div className="flex items-center justify-center h-16 px-4 bg-gradient-to-r from-blue-600 to-purple-600 border-b border-gray-800">
          <Heart className="w-8 h-8 text-white mr-2" />
          <span className="text-xl font-bold text-white">ThrivePulse</span>
        </div>

        {/* Navigation */}
        <nav className="mt-8 px-4">
          <ul className="space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              
              return (
                <li key={item.id}>
                  <button
                    onClick={() => {
                      setActiveTab(item.id);
                      setSidebarOpen(false); // Close mobile sidebar
                    }}
                    className={`
                      w-full flex items-center px-4 py-3 text-left rounded-lg transition-all duration-200 group
                      ${isActive 
                        ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg' 
                        : 'text-gray-300 hover:bg-gray-800/50 hover:text-white'
                      }
                    `}
                  >
                    <Icon className={`w-5 h-5 mr-3 ${isActive ? 'text-white' : 'text-gray-400 group-hover:text-blue-400'}`} />
                    <span className="font-medium">{item.name}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Logout button */}
        <div className="absolute bottom-8 left-4 right-4">
          <button
            onClick={handleLogout}
            className="w-full flex items-center px-4 py-3 text-left rounded-lg text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-all duration-200 border border-red-500/20"
          >
            <LogOut className="w-5 h-5 mr-3" />
            <span className="font-medium">Logout</span>
          </button>
        </div>

        {/* Motivational Quote */}
        <div className="absolute bottom-20 left-4 right-4">
          <div className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 backdrop-blur p-4 rounded-lg border border-blue-500/20">
            <p className="text-sm text-gray-300 italic text-center">
              "Your mental health is a priority. Your happiness is essential. Your self-care is a necessity."
            </p>
          </div>
        </div>
      </div>
    </>
  );
}

export default Sidebar; 