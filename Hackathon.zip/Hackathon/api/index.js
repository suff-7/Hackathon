const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const admin = require('firebase-admin');

// Initialize Firebase Admin SDK
const serviceAccount = {
  type: "service_account",
  project_id: "thrivepulse-88544",
  private_key_id: "465ac430e34127bc545a19321e191c5299c75a37",
  private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCiKNzQe7s9F51H\nvdf36EpCw5zUT+/RdqtSHIrkw65T2s1NCp0aMp8LpIXMrVHJAfdBoP2znXRUKDaY\nR9vNdWEHKWjj5IEDkvCPiZ8d3qoSoEuP6XdLkIAPVTIWty4vptG3OgEhIjAtrP8Z\n8vVo3hNSoPPMpwXV0XokCYF0BJ11i4J/83GMJxhnMDlu95PsFd03v1m3mUVXyCM3\neAYC/5TFXJ9YE0NcSvSQ2azgMlNN7zFnm9jv1mLZKGARoaPHcebFLfRnkQP3x6wz\nMq1KYwqBw8xeP7LSQkcWMiFaB4o3eVWXWfDbDxMB5sLT+D/3oVoEPRDYcr0YIPPJ\nW01V/LflAgMBAAECggEAE58SKP/vxhKna1jjWxH2emGlBmOtxxCu5j6h59BttaPS\nF7JjFBpv+D6uGfgW31Wnj39lc2hn/Q7onECFrjS3yuAN2xV5Lu+GwDeM01ZwCdTv\nj7hWQQR5GmHar7j2k7mBwsP4AwRaBAzcyU0GuOu2NtdW6LqFEDxKpTWpPlqYmvJX\nD4SIuW9Rjzix8VAsa7KE+ebhISIp6s8NMMFi9kIWmPtMXC3h85firGoGJ2DvuShH\nmrPyF6q6LJHoybrQ6H95O0uKLjaBwZhGcMpD9rKxJG7Ub4lQwM3izvcy9zpyC47P\noMj9yI/JMJ2W4nNe98wB+wr0KEJu/4382oNVFvhtAQKBgQDf1CpgbpqNh+9pr6zh\nB4S0OA2YuM1YkzSkEw7Rau5+HGRZRWTcyvJocZvmu55O/dRwnjg53RkmFo+khuCK\n+N/H5po5utfXNtM33SQWXLlIvtV16Og9uKSe0945fHm8WVpgMvG4zGFVNkUrsyZg\nGHBZRDhFEbi6DRgsLEovkeWjRQKBgQC5d5DCJ0wCjtyRszbizd/X07r0ENVAvEfT\nmXLVsexjVCKFO/63GN96vpCoNDt2dfCAxWaQ0R1hMoyt/rnHzNCxV60OOs7/ryJL\nXhrVI0ugWFXOqp2hUrw1f+wm7n0rfJmogibL3GWAUQ/Rn2xlrWFeh23/hKhYVXIi\n9O8J70y8IQKBgGli0wUObpSe4VnIjkRxrsjP747tzDmdLdbm5j4x89LK+XCS3Nec\ncqA8haQQyIv2tXTE+kI8WN/3FXDo1IZ6gZr0d78guwmo1bBi3d/tjouy1nyqydZt\nvozNwr8cXZESHRxYQDm7eUSOxei6dCIgv504Iqpamrh2+9+ohtF5Bz9lAoGAB28u\ng0nV9yhI2SJI6fB8r4cSMGRYV/70FhxJiR1Xr2eY9qRAApDhrGblH4jwdUAnAtJm\n2Rk4x0OidfsG8WZZWzJ7gl2DHKalhkXgZ3jBuEyyK9WU+fl6B9731Vur8slM039c\nFMHh47HcI3fzfWPkykg9dYeYw+mw6IvO5SQNfGECgYBCdcTIZ+hrYQk9ys7/pRXY\naHcxWjUzy09uc6gBLj/T4LsZbNv2MtRkJr+rXYgzSL4n1Lyhz21aZMYGnsNN4LjU\nYPRJkkXQPEYXwATyWS6oNRrUmpl07ICr3oAjARlHFdAbL2GJEIiNoEnjCfja+d9F\nsm4qbkGTYOwID8MEkTiTFw==\n-----END PRIVATE KEY-----\n",
  client_email: "firebase-adminsdk-fbsvc@thrivepulse-88544.iam.gserviceaccount.com",
  client_id: "105656789139459139098",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40thrivepulse-88544.iam.gserviceaccount.com",
  universe_domain: "googleapis.com"
};

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  projectId: 'thrivepulse-88544'
});

const db = admin.firestore();
const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(helmet());
app.use(cors({
  origin: ['http://localhost:3000', 'https://thrivepulse.vercel.app'],
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use(limiter);

// Middleware to verify Firebase token
const verifyToken = async (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  try {
    const decodedToken = await admin.auth().verifyIdToken(token);
    req.user = decodedToken;
    next();
  } catch (error) {
    console.error('Token verification failed:', error);
    return res.status(401).json({ error: 'Invalid token' });
  }
};

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Auth endpoints
app.post('/api/auth/verify', verifyToken, (req, res) => {
  res.json({ user: req.user, message: 'Token verified successfully' });
});

// User management endpoints
app.get('/api/users/profile', verifyToken, async (req, res) => {
  try {
    const userDoc = await db.collection('users').doc(req.user.uid).get();
    if (!userDoc.exists) {
      return res.status(404).json({ error: 'User profile not found' });
    }
    res.json(userDoc.data());
  } catch (error) {
    console.error('Error fetching user profile:', error);
    res.status(500).json({ error: 'Failed to fetch user profile' });
  }
});

app.post('/api/users/profile', verifyToken, async (req, res) => {
  try {
    const { name, role, department } = req.body;
    const userData = {
      name,
      email: req.user.email,
      role: role || 'employee',
      department: department || 'general',
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };
    
    await db.collection('users').doc(req.user.uid).set(userData, { merge: true });
    res.json({ message: 'Profile updated successfully', data: userData });
  } catch (error) {
    console.error('Error updating user profile:', error);
    res.status(500).json({ error: 'Failed to update user profile' });
  }
});

// Mood check-in endpoints
app.post('/api/mood/checkin', verifyToken, async (req, res) => {
  try {
    const { mood, notes, anonymous } = req.body;
    const checkinData = {
      userId: anonymous ? null : req.user.uid,
      mood: parseInt(mood),
      notes: notes || '',
      anonymous: !!anonymous,
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      date: new Date().toISOString().split('T')[0]
    };
    
    const docRef = await db.collection('moodCheckins').add(checkinData);
    res.json({ message: 'Mood check-in recorded', id: docRef.id });
  } catch (error) {
    console.error('Error recording mood check-in:', error);
    res.status(500).json({ error: 'Failed to record mood check-in' });
  }
});

app.get('/api/mood/history', verifyToken, async (req, res) => {
  try {
    const { days = 30 } = req.query;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(days));
    
    const snapshot = await db.collection('moodCheckins')
      .where('userId', '==', req.user.uid)
      .where('timestamp', '>=', startDate)
      .orderBy('timestamp', 'desc')
      .get();
    
    const moodHistory = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      timestamp: doc.data().timestamp?.toDate()
    }));
    
    res.json(moodHistory);
  } catch (error) {
    console.error('Error fetching mood history:', error);
    res.status(500).json({ error: 'Failed to fetch mood history' });
  }
});

// Task management endpoints
app.get('/api/tasks', verifyToken, async (req, res) => {
  try {
    const snapshot = await db.collection('tasks')
      .where('assignee', '==', req.user.uid)
      .orderBy('createdAt', 'desc')
      .get();
    
    const tasks = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      dueDate: doc.data().dueDate?.toDate(),
      completedAt: doc.data().completedAt?.toDate()
    }));
    
    res.json(tasks);
  } catch (error) {
    console.error('Error fetching tasks:', error);
    res.status(500).json({ error: 'Failed to fetch tasks' });
  }
});

app.post('/api/tasks', verifyToken, async (req, res) => {
  try {
    const { title, description, dueDate, priority, category } = req.body;
    const taskData = {
      title,
      description: description || '',
      assignee: req.user.uid,
      status: 'pending',
      priority: priority || 'medium',
      category: category || 'general',
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      dueDate: dueDate ? new Date(dueDate) : null,
      completedAt: null
    };
    
    const docRef = await db.collection('tasks').add(taskData);
    res.json({ message: 'Task created successfully', id: docRef.id });
  } catch (error) {
    console.error('Error creating task:', error);
    res.status(500).json({ error: 'Failed to create task' });
  }
});

app.patch('/api/tasks/:taskId', verifyToken, async (req, res) => {
  try {
    const { taskId } = req.params;
    const { status, ...updateData } = req.body;
    
    const updates = {
      ...updateData,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };
    
    if (status === 'completed') {
      updates.completedAt = admin.firestore.FieldValue.serverTimestamp();
      updates.status = 'completed';
    } else if (status) {
      updates.status = status;
    }
    
    await db.collection('tasks').doc(taskId).update(updates);
    res.json({ message: 'Task updated successfully' });
  } catch (error) {
    console.error('Error updating task:', error);
    res.status(500).json({ error: 'Failed to update task' });
  }
});

// Anonymous messaging endpoints
app.post('/api/messages/anonymous', verifyToken, async (req, res) => {
  try {
    const { message, department, priority } = req.body;
    const messageData = {
      message,
      department: department || 'general',
      priority: priority || 'medium',
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      resolved: false,
      response: null
    };
    
    const docRef = await db.collection('anonymousMessages').add(messageData);
    res.json({ message: 'Anonymous message sent successfully', id: docRef.id });
  } catch (error) {
    console.error('Error sending anonymous message:', error);
    res.status(500).json({ error: 'Failed to send anonymous message' });
  }
});

// Team metrics endpoints
app.get('/api/metrics/team', verifyToken, async (req, res) => {
  try {
    const { days = 7 } = req.query;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(days));
    
    // Get mood data
    const moodSnapshot = await db.collection('moodCheckins')
      .where('timestamp', '>=', startDate)
      .get();
    
    // Get task data
    const taskSnapshot = await db.collection('tasks')
      .where('createdAt', '>=', startDate)
      .get();
    
    const moodData = moodSnapshot.docs.map(doc => doc.data());
    const taskData = taskSnapshot.docs.map(doc => doc.data());
    
    // Calculate metrics
    const averageMood = moodData.length > 0 
      ? moodData.reduce((sum, item) => sum + item.mood, 0) / moodData.length 
      : 0;
    
    const completedTasks = taskData.filter(task => task.status === 'completed').length;
    const totalTasks = taskData.length;
    const productivityScore = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
    
    res.json({
      averageMood: Math.round(averageMood * 10) / 10,
      productivityScore: Math.round(productivityScore * 10) / 10,
      completedTasks,
      totalTasks,
      activeUsers: new Set(moodData.map(item => item.userId)).size,
      period: `${days} days`
    });
  } catch (error) {
    console.error('Error fetching team metrics:', error);
    res.status(500).json({ error: 'Failed to fetch team metrics' });
  }
});

// Therapist session endpoints
app.post('/api/therapist/session', verifyToken, async (req, res) => {
  try {
    const { scheduledTime, sessionType, notes } = req.body;
    const sessionData = {
      userId: req.user.uid,
      scheduledTime: new Date(scheduledTime),
      sessionType: sessionType || 'general',
      status: 'scheduled',
      notes: notes || '',
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    };
    
    const docRef = await db.collection('therapistSessions').add(sessionData);
    res.json({ message: 'Therapist session scheduled successfully', id: docRef.id });
  } catch (error) {
    console.error('Error scheduling therapist session:', error);
    res.status(500).json({ error: 'Failed to schedule therapist session' });
  }
});

app.get('/api/therapist/sessions', verifyToken, async (req, res) => {
  try {
    const snapshot = await db.collection('therapistSessions')
      .where('userId', '==', req.user.uid)
      .orderBy('scheduledTime', 'asc')
      .get();
    
    const sessions = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      scheduledTime: doc.data().scheduledTime?.toDate(),
      createdAt: doc.data().createdAt?.toDate()
    }));
    
    res.json(sessions);
  } catch (error) {
    console.error('Error fetching therapist sessions:', error);
    res.status(500).json({ error: 'Failed to fetch therapist sessions' });
  }
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Unhandled error:', error);
  res.status(500).json({ error: 'Internal server error' });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 ThrivePulse API server running on port ${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/api/health`);
  console.log(`🔐 Auth endpoints: http://localhost:${PORT}/api/auth/*`);
  console.log(`📈 Metrics endpoints: http://localhost:${PORT}/api/metrics/*`);
  console.log(`💬 Messages endpoints: http://localhost:${PORT}/api/messages/*`);
  console.log(`🤖 Therapist endpoints: http://localhost:${PORT}/api/therapist/*`);
  console.log(`✅ Tasks endpoints: http://localhost:${PORT}/api/tasks/*`);
});

// Export for Vercel
module.exports = app; 